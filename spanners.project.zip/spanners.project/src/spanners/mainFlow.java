package spanners;

/*project TODO:
-talk about the input - should be random/ partly random/ constant/ some options?
-call by reference - problem! make the getters better.
-maybe create abstract class for both kinds of graphs?
*/

public class mainFlow {
	
	 public static void main(String[] args) {
	        System.out.println("OK!");
	        
	        /*create random initial graph*/
	        System.out.println("Building random graph...");
	        graph originalGraph = new graph();
	        System.out.println("The Original Graph:");
	        originalGraph.printAdjacencyMatrix();
	        
	        /*create graph spanner*/    
	        System.out.println("Building spanner to the graph with k="+originalGraph.getK()+":");
	        spanner spannerGraph = new spanner(originalGraph.getAdjacencyMatrix(),
	        								   originalGraph.getK());
	        
	        System.out.println("The Spanner:");
	        spannerGraph.printNewAdjacencyMatrix();
	        
	    }
}
