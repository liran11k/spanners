package spanners;

import java.util.Random;

/*project TODO:
-talk about the input - should be random/ partly random/ constant/ some options?
-call by reference - problem! make the getters better.
-maybe create abstract class for both kinds of graphs?
*/

public class mainFlow {
	
	 public static void main(String[] args) {
	        System.out.println("START:");
	        System.out.println();
	        
	        /*create graph*/
	        int user_choice = 1;
	        graph originalGraph;
//	        System.out.println("choose one way to build a graph:");
//	        System.out.println("1. random graph");
//	        System.out.println("2. user graph");
	        /*TODO* - GET INPUT FROM USER*/
	        if (user_choice==2){
	        	/*TODO* - GET INPUT to originalGraph FROM USER*/
	        	originalGraph = new graph();
	        }
	        else{
	        	originalGraph = new graph();
	        } 
	        System.out.println("The Original Graph:");
	        originalGraph.printAdjacencyMatrix();
	        System.out.println();

	        
	        /*create graph spanner*/   
	        int k;
	        user_choice = 1;
//	        System.out.println("choose one way to get a k:");
//	        System.out.println("1. random k (between 1 .. n");
//	        System.out.println("2. user k");
	        if(user_choice==2){
	        	/*TODO* - GET INPUT to k FROM USER*/
	        	k=2;
	        }
	        else{
	        	Random rand = new Random();
	        	k = rand.nextInt(originalGraph.getGraphSize()-2)+2; 
	        }	        
	        
	        System.out.println("Building spanner to the graph with k="+k+":");
	        graph spanner = new graph(originalGraph.buildSpanner(k));
	        
	        System.out.println("The Spanner:");
	        spanner.printAdjacencyMatrix();

	        
	    }
}
