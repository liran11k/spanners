package spanners;

import java.util.Random;
	
public class graph {
	
	int[][] adjacencyMatrix;
	int k;
	
	/*empty constructor (random)*/
	graph(){
		Random rand = new Random();
		adjacencyMatrix = buildRandomAdjacencyMatrix();
	    k = rand.nextInt(adjacencyMatrix.length); 		
	}
	
	/*graph and k constructor*/
	graph(int[][] adjacencyMatrix, int k){
		this.adjacencyMatrix = adjacencyMatrix;
	    this.k = k; 		
	}
	
	/*only k constructor*/
	graph(int k){
		/*TODO*/
	}
	
	/*only graph constructor*/
	graph(int[][] adjacencyMatrix){
		/*TODO*/
	}
	
	private static int[][] buildRandomAdjacencyMatrix() {	
		Random rand = new Random();
		int matrixSize = rand.nextInt(50) + 2;
		//matrixSize = 5;
		int[][] matrix = new int[matrixSize][matrixSize];
		int isNeighbour;

		for(int i=0; i<matrix.length; i++){
			matrix[i][i] = 0;
			
			for(int j=i+1; j<matrix.length; j++){
				isNeighbour = rand.nextInt(2);
				matrix[i][j] = isNeighbour;
				matrix[j][i] = isNeighbour;
			}
		}
		return matrix;
	}
	
	protected int[][] getAdjacencyMatrix(){
		return adjacencyMatrix;
	}
	
	protected int getK(){
		return k;
	}
	
	protected void printAdjacencyMatrix(){
		System.out.println("length: "+ adjacencyMatrix.length);
		for(int i=0; i<adjacencyMatrix.length; i++){			
			for(int j=0; j<adjacencyMatrix.length; j++){
				System.out.print(adjacencyMatrix[i][j]);
			}
			System.out.println("");
		}
		
	}

}
