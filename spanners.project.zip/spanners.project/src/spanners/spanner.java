package spanners;

import java.util.Set;

public class spanner {
	
	int[][] oldAdjacencyMatrix;
	int[][] newAdjacencyMatrix;
	int k;

	public spanner(int[][] adjacencyMatrix, int k) {
		this.oldAdjacencyMatrix = adjacencyMatrix;
		this.k = k;
		int size = oldAdjacencyMatrix.length;
		this.newAdjacencyMatrix = new int[size][size];
		buildSpanner(size);
	}
	
	private int[][] buildSpanner(int size) {
		Set p = buildPratition();
		int[][] clusterMatrix = buildClusterMatrix(p);
		return null;
	}

	private int[][] buildClusterMatrix(Set p) {
		// TODO Auto-generated method stub
		return null;
	}

	private Set buildPratition() {
		// TODO Auto-generated method stub
		return null;
	}

	protected void printNewAdjacencyMatrix(){
		System.out.println("length: "+ newAdjacencyMatrix.length);
		for(int i=0; i<newAdjacencyMatrix.length; i++){			
			for(int j=0; j<newAdjacencyMatrix.length; j++){
				System.out.print(newAdjacencyMatrix[i][j]);
			}
			System.out.println("");
		}	
	}

}
